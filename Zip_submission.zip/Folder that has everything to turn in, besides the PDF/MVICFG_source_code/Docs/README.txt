===================================
README
===================================
This folder contains the documentation for Hydrogen. The "Documentation.pdf" provides in detail the structure and
functionality of of all the classes and files in the used for Hydrogen along with the Quick Starting Guide. If you
prefer a browsable and reachable format, just click on "index.html" inside the "HTML" folder.
