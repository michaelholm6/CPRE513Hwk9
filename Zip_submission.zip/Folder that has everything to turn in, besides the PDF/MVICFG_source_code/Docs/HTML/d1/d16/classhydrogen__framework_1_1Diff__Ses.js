var classhydrogen__framework_1_1Diff__Ses =
[
    [ "Diff_Ses", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ab46746154ddb52fe74f8696d54b98511", null ],
    [ "Diff_Ses", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#a07e386ccdd0f766acd6d6d22c3ebec4e", null ],
    [ "~Diff_Ses", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ae92b0da29dd993959ce70f087f2d71b5", null ],
    [ "addSequence", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#aad048cb9107135ef5fce5e808814872d", null ],
    [ "getSequence", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#aed7a641eb4b4f795727d3276c7cf9d72", null ],
    [ "isChange", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ac10503e86638589e9b7446cf3577e01e", null ],
    [ "isOnlyAdd", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ae54607b1f89be5b184184e1d68d8b23d", null ],
    [ "isOnlyCopy", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#a1c9e213ee78906eb104ab92e5c385999", null ],
    [ "isOnlyDelete", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#a5d41ea9f3fcbe5f571195350eba8221d", null ],
    [ "isOnlyOneOperation", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ae859a3907950e5e92593369846331962", null ],
    [ "deletesFirst", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#aa5e90a29bb7d325a4f720637c278e258", null ],
    [ "nextDeleteIdx", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#a10d35c8d1430fe77e32d70d7da144cbd", null ],
    [ "onlyAdd", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#aba745a69800976c007990d2822e36f23", null ],
    [ "onlyCopy", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ae648f6297bea82d9bc68a32642e316a8", null ],
    [ "onlyDelete", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ab26550f4647d1a61f8640db4c2422b8b", null ],
    [ "sequenceDS", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html#a0669a93f467c8744af631a7fdb20540f", null ]
];