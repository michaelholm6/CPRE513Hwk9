var files_dup =
[
    [ "Diff_Mapping.cpp", "dd/d6f/Diff__Mapping_8cpp.html", null ],
    [ "Diff_Mapping.hpp", "df/d13/Diff__Mapping_8hpp.html", [
      [ "Diff_Mapping", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html", "d0/d21/classhydrogen__framework_1_1Diff__Mapping" ]
    ] ],
    [ "Diff_Util.cpp", "da/d02/Diff__Util_8cpp.html", null ],
    [ "Diff_Util.hpp", "db/dba/Diff__Util_8hpp.html", [
      [ "Diff_Compare", "d1/d32/classhydrogen__framework_1_1Diff__Compare.html", "d1/d32/classhydrogen__framework_1_1Diff__Compare" ],
      [ "Diff_Sequence", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence.html", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence" ],
      [ "Diff_Ses", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html", "d1/d16/classhydrogen__framework_1_1Diff__Ses" ],
      [ "Diff_Util", "d2/d24/classhydrogen__framework_1_1Diff__Util.html", "d2/d24/classhydrogen__framework_1_1Diff__Util" ],
      [ "Diff_Vars", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html", "d3/db1/classhydrogen__framework_1_1Diff__Vars" ],
      [ "eleminfo", "d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html", "d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo" ],
      [ "Point", "dd/dd2/structhydrogen__framework_1_1Diff__Vars_1_1Point.html", "dd/dd2/structhydrogen__framework_1_1Diff__Vars_1_1Point" ]
    ] ],
    [ "Get_Input.cpp", "da/dc7/Get__Input_8cpp.html", null ],
    [ "Get_Input.hpp", "df/ddd/Get__Input_8hpp.html", [
      [ "Hydrogen", "df/d43/classhydrogen__framework_1_1Hydrogen.html", "df/d43/classhydrogen__framework_1_1Hydrogen" ]
    ] ],
    [ "Graph.cpp", "dd/dea/Graph_8cpp.html", "dd/dea/Graph_8cpp" ],
    [ "Graph.hpp", "d9/d69/Graph_8hpp.html", "d9/d69/Graph_8hpp" ],
    [ "Graph_Edge.cpp", "d2/d0d/Graph__Edge_8cpp.html", null ],
    [ "Graph_Edge.hpp", "df/d2f/Graph__Edge_8hpp.html", [
      [ "Graph_Edge", "d2/d64/classhydrogen__framework_1_1Graph__Edge.html", "d2/d64/classhydrogen__framework_1_1Graph__Edge" ]
    ] ],
    [ "Graph_Function.cpp", "da/d0a/Graph__Function_8cpp.html", null ],
    [ "Graph_Function.hpp", "d6/dba/Graph__Function_8hpp.html", [
      [ "Graph_Function", "dc/d7a/classhydrogen__framework_1_1Graph__Function.html", "dc/d7a/classhydrogen__framework_1_1Graph__Function" ]
    ] ],
    [ "Graph_Instruction.hpp", "d1/d05/Graph__Instruction_8hpp.html", [
      [ "Graph_Instruction", "da/df5/classhydrogen__framework_1_1Graph__Instruction.html", "da/df5/classhydrogen__framework_1_1Graph__Instruction" ]
    ] ],
    [ "Graph_Line.cpp", "d2/d14/Graph__Line_8cpp.html", null ],
    [ "Graph_Line.hpp", "df/ddd/Graph__Line_8hpp.html", [
      [ "Graph_Line", "d8/d0b/classhydrogen__framework_1_1Graph__Line.html", "d8/d0b/classhydrogen__framework_1_1Graph__Line" ]
    ] ],
    [ "Hydrogen.cpp", "de/d64/Hydrogen_8cpp.html", "de/d64/Hydrogen_8cpp" ],
    [ "Module.cpp", "d4/dd4/Module_8cpp.html", null ],
    [ "Module.hpp", "d5/d44/Module_8hpp.html", [
      [ "Module", "da/d32/classhydrogen__framework_1_1Module.html", "da/d32/classhydrogen__framework_1_1Module" ]
    ] ],
    [ "MVICFG.cpp", "db/d17/MVICFG_8cpp.html", "db/d17/MVICFG_8cpp" ],
    [ "MVICFG.hpp", "df/de4/MVICFG_8hpp.html", "df/de4/MVICFG_8hpp" ],
    [ "SystemBuilder.py", "d2/dbb/SystemBuilder_8py_source.html", null ]
];