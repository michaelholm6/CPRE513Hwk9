var searchData=
[
  ['eleminfo',['eleminfo',['../d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html',1,'hydrogen_framework::Diff_Vars']]]
];
