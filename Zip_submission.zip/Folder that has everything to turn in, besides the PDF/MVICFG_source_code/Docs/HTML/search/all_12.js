var searchData=
[
  ['updatemvicfgversion',['updateMVICFGVersion',['../db/d17/MVICFG_8cpp.html#a2ebefd41917d6565942bb86ec72f6adc',1,'hydrogen_framework']]]
];
