var searchData=
[
  ['m',['M',['../d2/d24/classhydrogen__framework_1_1Diff__Util.html#a10ca31bc146cd1b2e5725cd7a8dafcb8',1,'hydrogen_framework::Diff_Util']]],
  ['matchedlines',['matchedLines',['../d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a463f63d7e645a004d8241e8fdc56412c',1,'hydrogen_framework::Diff_Mapping']]],
  ['max_5fcordinates_5fsize',['MAX_CORDINATES_SIZE',['../d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a3be8ebf3f80f9ccdb0d0171d29a0bb69',1,'hydrogen_framework::Diff_Vars']]],
  ['modcontext',['modContext',['../da/d32/classhydrogen__framework_1_1Module.html#ad717d78fee0acbff7b60810c94687125',1,'hydrogen_framework::Module']]],
  ['modfiles',['modFiles',['../da/d32/classhydrogen__framework_1_1Module.html#a686f8f88189ddeae696d93e1016a5c70',1,'hydrogen_framework::Module']]],
  ['modptr',['modPtr',['../da/d32/classhydrogen__framework_1_1Module.html#a51703c08a2f84a7bddb4126e6519ac77',1,'hydrogen_framework::Module']]],
  ['modversion',['modVersion',['../da/d32/classhydrogen__framework_1_1Module.html#a63ad7c546173954e02ab257c598504a7',1,'hydrogen_framework::Module']]]
];
