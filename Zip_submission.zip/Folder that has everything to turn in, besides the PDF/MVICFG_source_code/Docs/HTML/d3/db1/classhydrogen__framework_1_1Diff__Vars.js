var classhydrogen__framework_1_1Diff__Vars =
[
    [ "eleminfo", "d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html", "d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo" ],
    [ "Point", "dd/dd2/structhydrogen__framework_1_1Diff__Vars_1_1Point.html", "dd/dd2/structhydrogen__framework_1_1Diff__Vars_1_1Point" ],
    [ "editPath", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#ad62aed5e879340e48652cfdacaa17aa1", null ],
    [ "editPathCordinates", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#ad5382f9e8b834546f26cd8b8e2d7c334", null ],
    [ "elem", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a3ae6a2caf55871d355b4c56fd16c9627", null ],
    [ "elemInfo", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a8ae3fde02b1c21cc86e76f75290426de", null ],
    [ "elemList", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a57640a8253315f64370a1afc4793f20e", null ],
    [ "elemList_iter", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#ae0cfdac0d48c9f5a1dcdabb8c74fd78f", null ],
    [ "elemVec", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#aca48fa3426a7643d350692d445d13ffb", null ],
    [ "elemVec_iter", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a2b4081b4e477b1a73f645db1d393f796", null ],
    [ "P", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#aaa24adaad667f5703b891742eeb4630c", null ],
    [ "sequence", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a52485c8f3da853247ed6cb7534e64fb9", null ],
    [ "sequence_const_iter", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a192ed2fcc39900d0cc8cbcafdabf9cf1", null ],
    [ "sequence_iter", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a6cbfa6e43892c39c9d4b1d3d88794cf0", null ],
    [ "sesElem", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#aaafe7a1a734dae8d2b6b87c4cd02026b", null ],
    [ "sesElemVec", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#abc8fbe507c31784819134f87a9bbd1e9", null ],
    [ "sesElemVec_iter", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a8f6b4fbd0335fb5df0c4e1463496b344", null ],
    [ "SES_TYPE", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a6225d2245dc139f3370fc3ec348e8ca9", [
      [ "SES_DELETE", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a6225d2245dc139f3370fc3ec348e8ca9a84a6651458b701c46bd2955b132990cf", null ],
      [ "SES_COMMON", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a6225d2245dc139f3370fc3ec348e8ca9a04a4191eb34a4d9178239c344843fafd", null ],
      [ "SES_ADD", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a6225d2245dc139f3370fc3ec348e8ca9a2e4cac696c4a6fbb10662b593b1fb4ca", null ]
    ] ],
    [ "Diff_Vars", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#ad6bf7c7742395d18d53462649bb58550", null ],
    [ "~Diff_Vars", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a08f9fd54858aefd13eafbb3ad5e4d24c", null ],
    [ "MAX_CORDINATES_SIZE", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a3be8ebf3f80f9ccdb0d0171d29a0bb69", null ],
    [ "SES_MARK_ADD", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#aabb16a189824590da58beb182c2922e9", null ],
    [ "SES_MARK_COMMON", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a2cf9fc118f3b09e048e9560b231a1ecc", null ],
    [ "SES_MARK_DELETE", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html#a3f76d4e29d3e2f0ae96b1a5352fbba7f", null ]
];