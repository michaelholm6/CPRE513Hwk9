var annotated_dup =
[
    [ "hydrogen_framework", null, [
      [ "Diff_Compare", "d1/d32/classhydrogen__framework_1_1Diff__Compare.html", "d1/d32/classhydrogen__framework_1_1Diff__Compare" ],
      [ "Diff_Mapping", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html", "d0/d21/classhydrogen__framework_1_1Diff__Mapping" ],
      [ "Diff_Sequence", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence.html", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence" ],
      [ "Diff_Ses", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html", "d1/d16/classhydrogen__framework_1_1Diff__Ses" ],
      [ "Diff_Util", "d2/d24/classhydrogen__framework_1_1Diff__Util.html", "d2/d24/classhydrogen__framework_1_1Diff__Util" ],
      [ "Diff_Vars", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html", "d3/db1/classhydrogen__framework_1_1Diff__Vars" ],
      [ "Graph", "d4/d7a/classhydrogen__framework_1_1Graph.html", "d4/d7a/classhydrogen__framework_1_1Graph" ],
      [ "Graph_Edge", "d2/d64/classhydrogen__framework_1_1Graph__Edge.html", "d2/d64/classhydrogen__framework_1_1Graph__Edge" ],
      [ "Graph_Function", "dc/d7a/classhydrogen__framework_1_1Graph__Function.html", "dc/d7a/classhydrogen__framework_1_1Graph__Function" ],
      [ "Graph_Instruction", "da/df5/classhydrogen__framework_1_1Graph__Instruction.html", "da/df5/classhydrogen__framework_1_1Graph__Instruction" ],
      [ "Graph_Line", "d8/d0b/classhydrogen__framework_1_1Graph__Line.html", "d8/d0b/classhydrogen__framework_1_1Graph__Line" ],
      [ "Hydrogen", "df/d43/classhydrogen__framework_1_1Hydrogen.html", "df/d43/classhydrogen__framework_1_1Hydrogen" ],
      [ "Module", "da/d32/classhydrogen__framework_1_1Module.html", "da/d32/classhydrogen__framework_1_1Module" ]
    ] ]
];